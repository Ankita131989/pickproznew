<?php
$hs = 17;
$as = 13;
if($as > $hs)
{echo $as;}
else if($as<$hs)
{echo $hs;}


?>
