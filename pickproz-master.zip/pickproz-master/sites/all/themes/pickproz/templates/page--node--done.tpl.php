<div id="page" class="container">

  
  <?php print $messages; ?>
  

  <div id="columns">
    <div class="columns-inner clearfix">
      <div id="content-column">
        <div class="content-inner">
          <div id="main-content" role="main">
            <div id="content"
              <div class="field field-name-field-logo field-type-image field-label-hidden"><div class="field-items"><div class="field-item even"><img typeof="foaf:Image" src="http://pickproz.minortech.com/sites/default/files/default_images/logo.png" alt=""></div></div></div>
              <?php print render($page['content']); ?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
